##### Disciplina Inteligência Artificial e Robótica - Ciência da Computação FEI

# Projeto Robótica
**Objetivo:** Encontrar a caixa de madeira "leve"
1.  O robô deve encontrar a caixa leve e parar de procurar
2.  Quando encontrar, ele deve parar e acender os leds

##  1. Integrantes

<div align="center">

| <img src="https://avatars.githubusercontent.com/evesantana" alt="Evelyn" width="50"/> | <img src="https://avatars.githubusercontent.com/camylladias" alt="Camylla" width="50"/> | <img src="https://avatars.githubusercontent.com/patriciamed" alt="Patricia" width="50" width="50"/>
|:------------------------------------------------------------------------------------------:|:-------------------------------------------------------------------------------------------:|:-------------------------------------------------------------------------------------------:|
| [Evelyn Santanna](https://github.com/evesantana)| [Camylla Dias](https://github.com/camylladias)| [Patrícia Medeiros](https://github.com/patriciamed)                          
</div>

##  2. Vídeo
link

##  3. Código Fonte
controlador.c